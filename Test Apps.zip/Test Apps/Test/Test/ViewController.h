//
//  ViewController.h
//  Test
//
//  Created by Samuel Arseneault on 2/4/15.
//  Copyright (c) 2015 Samuel Arseneault. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

//Button needs to know it has been clicked
//
int clicked;

@interface ViewController : UIViewController{
    
}

@end

